package com.example.DiningReviewAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiningReviewApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
